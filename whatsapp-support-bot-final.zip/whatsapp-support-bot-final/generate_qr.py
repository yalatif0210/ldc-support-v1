"""
generate_qr.py — Génère le QR code d'accès au bot WhatsApp.

Usage :
    python generate_qr.py
    python generate_qr.py --number +14155238886 --message "Bonjour Support"
"""
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask
import os
import argparse


def generate_whatsapp_qr(phone_number: str, pre_message: str = "Bonjour", output_path: str = "qr_bot_whatsapp.png"):
    """
    Génère un QR code WhatsApp stylé.

    Args:
        phone_number: Numéro au format international (ex: +14155238886)
        pre_message: Message pré-rempli à l'ouverture
        output_path: Chemin du fichier PNG de sortie
    """
    # Construire le lien wa.me
    clean_number = phone_number.replace('+', '').replace(' ', '').replace('-', '')
    import urllib.parse
    encoded_msg = urllib.parse.quote(pre_message)
    wa_url = f"https://wa.me/{clean_number}?text={encoded_msg}"

    print(f"🔗 URL générée : {wa_url}")

    # Générer le QR code avec style arrondi
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(wa_url)
    qr.make(fit=True)

    # QR code stylé avec coins arrondis et couleur verte WhatsApp
    img = qr.make_image(
        image_factory=StyledPilImage,
        module_drawer=RoundedModuleDrawer(),
        color_mask=SolidFillColorMask(
            front_color=(37, 211, 102),   # Vert WhatsApp
            back_color=(255, 255, 255)    # Fond blanc
        )
    )

    img.save(output_path)
    print(f"✅ QR code généré : {output_path}")
    print(f"📱 Les clients peuvent scanner ce QR pour accéder au bot.")
    return output_path, wa_url


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Générateur de QR code WhatsApp Bot')
    parser.add_argument('--number', default=os.getenv('TWILIO_WHATSAPP_NUMBER', '+14155238886').replace('whatsapp:', ''),
                        help='Numéro WhatsApp du bot (ex: +14155238886)')
    parser.add_argument('--message', default='Bonjour, je souhaite créer une demande de support.',
                        help='Message pré-rempli')
    parser.add_argument('--output', default='qr_bot_whatsapp.png',
                        help='Fichier de sortie PNG')

    args = parser.parse_args()
    path, url = generate_whatsapp_qr(args.number, args.message, args.output)
    print(f"\n💡 Partagez ce QR code sur :")
    print(f"   • Votre site web")
    print(f"   • Vos emails / newsletters")
    print(f"   • Des affiches en point de vente")
    print(f"   • Vos cartes de visite")
    print(f"\n🔗 Ou partagez directement le lien :\n   {url}")
